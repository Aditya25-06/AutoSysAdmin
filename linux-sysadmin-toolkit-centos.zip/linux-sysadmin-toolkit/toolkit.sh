#!/usr/bin/env bash
# ============================================================================
#  AutoSysAdmin - Linux System Administration & Monitoring Toolkit
#  Target: CentOS Stream 9 (also runs on RHEL 9, Rocky, AlmaLinux, Fedora)
#  Usage : sudo ./toolkit.sh            interactive menu
#          ./toolkit.sh --report        non-interactive health report (cron)
#          ./toolkit.sh --backup        non-interactive /etc backup   (cron)
# ============================================================================
set -u
BASE_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck source=/dev/null
source "$BASE_DIR/lib/common.sh"
for m in "$BASE_DIR"/modules/*.sh; do source "$m"; done

REPORT_DIR="${REPORT_DIR:-/var/log/toolkit-reports}"

health_report() {             # combines all modules into one dated text file
    mkdir -p "$REPORT_DIR" 2>/dev/null || REPORT_DIR="$HOME/toolkit-reports" && mkdir -p "$REPORT_DIR"
    local out="$REPORT_DIR/health_$(date +%F_%H%M).txt"
    {
        echo "AutoSysAdmin Health Report - $(date)"
        system_snapshot
        disk_usage_alert 80
        resource_alert 2 85
        zombie_check
        top_processes
        check_log 2>/dev/null && log_report
        user_report
    } 2>&1 | sed -r 's/\x1B\[[0-9;]*[mK]//g' > "$out"      # sed strips colour codes
    ok "Report saved to $out"
}

banner() {
    clear 2>/dev/null || true
    echo "${BOLD}${CYAN}"
    echo "  =============================================="
    echo "     AutoSysAdmin  |  Linux Admin Toolkit v1.0"
    echo "  =============================================="
    echo "${RESET}  Host: $(hostname)   User: $(whoami)   SELinux: $(selinux_mode)"
}

menu_storage() {
    while true; do
        header "Storage Management"
        echo " 1) Disk overview            5) Create LVM volume (wizard)"
        echo " 2) Disk usage alert         6) Extend logical volume"
        echo " 3) LVM status               7) Create swap file"
        echo " 4) Partition a disk         0) Back"
        read -rp "Choice: " c
        case $c in
            1) disk_overview;; 2) disk_usage_alert 80;; 3) lvm_status;;
            4) partition_helper;; 5) lvm_create_wizard;; 6) lvm_extend;;
            7) swap_create;; 0) return;; *) err "Invalid option";;
        esac; pause
    done
}

menu_users() {
    while true; do
        header "User & Group Management"
        echo " 1) Add user                 5) User report"
        echo " 2) Delete user              6) Shared directory (setgid + ACL)"
        echo " 3) Create group             7) Fix owner/group/mode"
        echo " 4) Add user to group        0) Back"
        read -rp "Choice: " c
        case $c in
            1) user_add;; 2) user_delete;; 3) group_create;; 4) group_add_member;;
            5) user_report;; 6) shared_dir_setup;; 7) perm_fix;;
            0) return;; *) err "Invalid option";;
        esac; pause
    done
}

menu_logs() {
    while true; do
        header "Log Analyzer (grep / sed / sort / uniq)"
        echo " 1) Summary                  4) Failed logins per hour"
        echo " 2) Top attacker IPs         5) Search log (regex)"
        echo " 3) Top targeted usernames   6) Anonymise log copy"
        echo " 0) Back"
        read -rp "Choice: " c
        case $c in
            1) failed_summary;; 2) top_attackers;; 3) top_targets;;
            4) hourly_pattern;; 5) search_log;; 6) anonymise_log;;
            0) return;; *) err "Invalid option";;
        esac; pause
    done
}

menu_selinux() {
    while true; do
        header "SELinux Security"
        echo " 1) Status and mode          4) Restore default context"
        echo " 2) Change mode (temporary)  5) Recent AVC denials"
        echo " 3) Explain file context     0) Back"
        read -rp "Choice: " c
        case $c in
            1) selinux_status;; 2) selinux_set_mode;; 3) selinux_file_context;;
            4) selinux_restore;; 5) selinux_denials;; 0) return;; *) err "Invalid option";;
        esac; pause
    done
}

menu_processes() {
    while true; do
        header "Processes & Scheduling"
        echo " 1) System snapshot          5) Zombie check"
        echo " 2) Top processes            6) Schedule daily health report"
        echo " 3) Find a process           7) Schedule weekly backup"
        echo " 4) Kill a process           8) List / remove cron jobs"
        echo " 9) Background job demo      0) Back"
        read -rp "Choice: " c
        case $c in
            1) system_snapshot;; 2) top_processes;; 3) find_process;; 4) kill_process;;
            5) zombie_check;; 6) schedule_health_report;; 7) schedule_backup;;
            8) list_cron_jobs; read -rp "Remove them? [y/N]: " r; [[ $r =~ ^[Yy]$ ]] && remove_cron_jobs;;
            9) background_demo;; 0) return;; *) err "Invalid option";;
        esac; pause
    done
}

main_menu() {
    while true; do
        banner
        echo
        echo "  1) Storage, LVM and Swap        (Experiments 1-2)"
        echo "  2) Users, Groups and ACLs       (Experiment 3)"
        echo "  3) Log Analyzer                 (Experiment 4)"
        echo "  4) SELinux Security             (Experiment 5)"
        echo "  5) Processes and Scheduling     (Experiment 6)"
        echo "  6) Generate full health report"
        echo "  0) Exit"
        read -rp "  Select an option: " ch
        case $ch in
            1) menu_storage;; 2) menu_users;; 3) menu_logs;; 4) menu_selinux;;
            5) menu_processes;; 6) health_report; pause;;
            0) echo "Goodbye!"; exit 0;; *) err "Invalid option"; sleep 1;;
        esac
    done
}

case "${1:-}" in
    --report) health_report ;;
    --backup) run_backup ;;
    --help|-h) sed -n '2,9p' "${BASH_SOURCE[0]}" ;;
    "") main_menu ;;
    *) err "Unknown option: $1 (try --help)"; exit 1 ;;
esac
