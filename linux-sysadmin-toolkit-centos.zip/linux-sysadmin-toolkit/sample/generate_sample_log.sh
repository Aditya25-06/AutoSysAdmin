#!/usr/bin/env bash
# Generates a realistic, reproducible CentOS-style /var/log/secure for testing
RANDOM=2026
out="${1:-$(dirname "$0")/secure_sample.log}"
attackers=(203.0.113.45 203.0.113.45 203.0.113.45 203.0.113.45 198.51.100.23 198.51.100.23 198.51.100.23 192.0.2.77 192.0.2.77 203.0.113.9 198.51.100.200)
baduser=(root root root admin admin test oracle ubuntu postgres guest)
good=(student student centos_admin)
: > "$out"
for i in $(seq 1 420); do
  h=$(printf "%02d" $((RANDOM % 24))); [[ $((RANDOM%3)) -ne 0 ]] && h=$(printf "%02d" $((1 + RANDOM % 5)))
  ts="Oct 24 $h:$(printf "%02d" $((RANDOM%60))):$(printf "%02d" $((RANDOM%60)))"
  ip=${attackers[$((RANDOM % ${#attackers[@]}))]}; u=${baduser[$((RANDOM % ${#baduser[@]}))]}
  port=$((30000 + RANDOM % 30000)); pid=$((1000 + RANDOM % 8000))
  if [[ $u == root ]]; then
    echo "$ts centos9 sshd[$pid]: Failed password for root from $ip port $port ssh2"
  else
    echo "$ts centos9 sshd[$pid]: Invalid user $u from $ip port $port"
    echo "$ts centos9 sshd[$pid]: Failed password for invalid user $u from $ip port $port ssh2"
  fi
  if [[ $((RANDOM % 9)) -eq 0 ]]; then
    gu=${good[$((RANDOM % 3))]}
    echo "$ts centos9 sshd[$pid]: Accepted password for $gu from 192.168.1.$((10+RANDOM%5)) port $port ssh2"
  fi
done | sort -s -k3,3 > "$out.tmp" && mv "$out.tmp" "$out"
echo "Generated $(wc -l < "$out") lines in $out"
