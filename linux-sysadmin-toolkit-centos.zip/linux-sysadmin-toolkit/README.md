# AutoSysAdmin - Linux System Administration & Monitoring Toolkit

A menu-driven Bash toolkit for **CentOS Stream 9** (RHEL-compatible) that automates the everyday tasks
from the six lab experiments: storage and LVM, users and ACLs, log analysis with filters,
SELinux checks, process control and cron scheduling.

## Project layout

```
linux-sysadmin-toolkit/
├── toolkit.sh                 # main menu + CLI flags (--report, --backup)
├── lib/common.sh              # colours, logging, validation helpers
├── modules/
│   ├── disk_lvm.sh            # Exp 1-2: disks, partitions, LVM, swap
│   ├── user_mgmt.sh           # Exp 3: users, groups, chmod/chown/chgrp, ACL
│   ├── log_analyzer.sh        # Exp 4: grep, sed, sort, uniq pipelines
│   ├── selinux_check.sh       # Exp 5: SELinux modes and contexts
│   ├── process_monitor.sh     # Exp 6: ps, kill, jobs
│   └── scheduler.sh           # Exp 6: cron + backup
└── sample/
    ├── generate_sample_log.sh # creates a test /var/log/secure
    └── secure_sample.log
```

## Quick start

```bash
sudo dnf install -y git lvm2 policycoreutils acl audit cronie    # packages used (dnf = yum on CentOS)
chmod +x toolkit.sh
sudo ./toolkit.sh                                  # interactive menu
sudo ./toolkit.sh --report                         # one-shot health report
LOG_FILE=sample/secure_sample.log ./toolkit.sh     # try log analyzer safely
```

## Experiment mapping

| Exp | Topic | Toolkit feature | Key commands |
|-----|-------|-----------------|--------------|
| 1 | Installation / Linux basics | System snapshot, `dnf` package check | `uname`, `uptime`, `dnf` |
| 2 | Disks, partitions, LVM, swap | Storage menu | `fdisk`, `mkfs`, `mount`, `pvcreate`, `vgcreate`, `lvcreate`, `lvextend`, `mkswap` |
| 3 | Users, groups, ACL | User menu | `useradd -e`, `userdel`, `groupadd`, `passwd`, `chmod`, `chgrp`, `chown`, `setfacl` |
| 4 | Filters and regex | Log analyzer | `grep`, `grep -E`, `grep -F`, `sed`, `sort`, `uniq` |
| 5 | SELinux | SELinux menu | `getenforce`, `setenforce`, `ls -Z`, `restorecon` |
| 6 | Processes and jobs | Process monitor, scheduler | `ps`, `kill`, `jobs`, `fg`, `bg`, `crontab` |

## Safety

* Destructive actions (format, delete, kill) always ask for confirmation.
* System accounts (UID < 1000) and PID 1 are protected.
* Test storage features on a **virtual machine** with a spare virtual disk only.
* Every action is written to `/var/log/sysadmin-toolkit.log`.

## Recovering a forgotten root password on your own CentOS Stream 9 VM (Experiment 5)

1. Reboot; at the GRUB menu press **e** on the first entry.
2. Append `rd.break` to the end of the line starting with `linux`, press **Ctrl+X**.
3. At the emergency shell:
   ```bash
   mount -o remount,rw /sysroot
   chroot /sysroot
   passwd root
   touch /.autorelabel      # lets SELinux relabel files after the change
   exit
   exit
   ```
4. The system relabels and reboots; log in with the new password.

> Only do this on machines you own or administer. Physical or console access plus a GRUB password
> is the standard protection against this method.

## Pushing to GitHub

```bash
git init && git add . && git commit -m "AutoSysAdmin: initial commit"
git branch -M main
git remote add origin https://github.com/<your-username>/linux-sysadmin-toolkit.git
git push -u origin main
```
