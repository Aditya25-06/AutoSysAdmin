#!/usr/bin/env bash
# lib/common.sh - shared helpers (colours, messages, logging, validation)

RED=$'\033[0;31m'; GREEN=$'\033[0;32m'; YELLOW=$'\033[1;33m'
BLUE=$'\033[0;34m'; CYAN=$'\033[0;36m'; BOLD=$'\033[1m'; RESET=$'\033[0m'

# Action log: /var/log when running as root, otherwise the user's home
ACTION_LOG="${TOOLKIT_LOG:-/var/log/sysadmin-toolkit.log}"
touch "$ACTION_LOG" 2>/dev/null || ACTION_LOG="$HOME/sysadmin-toolkit.log"

log_action() { echo "$(date '+%F %T') [$1] ${*:2}" >> "$ACTION_LOG" 2>/dev/null || true; }
info()  { echo "${CYAN}[INFO]${RESET} $*";   log_action INFO  "$*"; }
ok()    { echo "${GREEN}[ OK ]${RESET} $*";   log_action OK    "$*"; }
warn()  { echo "${YELLOW}[WARN]${RESET} $*";  log_action WARN  "$*"; }
err()   { echo "${RED}[FAIL]${RESET} $*" >&2; log_action ERROR "$*"; }

header() {
    echo
    echo "${BOLD}${BLUE}==============================================${RESET}"
    echo "${BOLD}${BLUE}  $*${RESET}"
    echo "${BOLD}${BLUE}==============================================${RESET}"
}

pause()   { read -rp $'\nPress Enter to continue...' _; }
confirm() { local a; read -rp "$1 [y/N]: " a; [[ $a =~ ^[Yy]$ ]]; }

require_root() {
    if [[ $EUID -ne 0 ]]; then
        err "This action needs root privileges. Re-run with: sudo ./toolkit.sh"
        return 1
    fi
}

need_cmd() {   # need_cmd <command>  -> fails politely if a tool is missing
    command -v "$1" &>/dev/null || { err "'$1' not found - find its package with: dnf provides '*/$1'"; return 1; }
}

valid_name() { [[ $1 =~ ^[a-z_][a-z0-9_-]{0,31}$ ]]; }   # Linux user/group name rule
