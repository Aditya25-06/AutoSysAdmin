#!/usr/bin/env bash
# modules/process_monitor.sh - Experiment 6: processes, signals and jobs

system_snapshot() {
    header "System Snapshot"
    printf "  %-14s %s\n" "Hostname:"    "$(hostname)"
    printf "  %-14s %s\n" "Kernel:"      "$(uname -r)"
    printf "  %-14s %s\n" "Uptime:"      "$(uptime -p 2>/dev/null || uptime)"
    printf "  %-14s %s\n" "Load (1/5/15):" "$(cut -d' ' -f1-3 /proc/loadavg)"
    printf "  %-14s %s\n" "Memory used:" "$(free -m | awk '/^Mem:/ {printf "%d MB of %d MB (%.0f%%)", $3, $2, $3*100/$2}')"
    printf "  %-14s %s\n" "Logged in:"   "$(who | wc -l) user(s)"
    printf "  %-14s %s\n" "SELinux:"     "$(selinux_mode 2>/dev/null)"
}

top_processes() {
    header "Top 5 Processes by CPU"
    ps -eo pid,user,%cpu,%mem,comm --sort=-%cpu | head -6
    header "Top 5 Processes by Memory"
    ps -eo pid,user,%cpu,%mem,comm --sort=-%mem | head -6
}

find_process() {
    read -rp "Process name to search: " name
    [[ -z $name ]] && return
    if pgrep -a -f -- "$name" > /tmp/.tk_pg 2>/dev/null && [[ -s /tmp/.tk_pg ]]; then
        cat /tmp/.tk_pg
    else
        warn "No process matching '$name'"
    fi
    rm -f /tmp/.tk_pg
}

kill_process() {              # polite SIGTERM first, SIGKILL only if needed
    read -rp "PID to terminate: " pid
    [[ $pid =~ ^[0-9]+$ ]] || { err "PID must be a number"; return; }
    [[ $pid -le 1 || $pid -eq $$ ]] && { err "Refusing to kill PID $pid"; return; }
    kill -0 "$pid" 2>/dev/null || { err "No such process"; return; }
    ps -p "$pid" -o pid,user,comm
    confirm "Send SIGTERM to $pid?" || return
    kill -15 "$pid"; sleep 2
    if kill -0 "$pid" 2>/dev/null; then
        warn "Process ignored SIGTERM."
        confirm "Force kill with SIGKILL (-9)?" && kill -9 "$pid" && ok "PID $pid killed"
    else
        ok "PID $pid terminated gracefully"
    fi
}

background_demo() {           # start / list a background job
    sleep 120 &
    local pid=$!
    ok "Started background job: sleep 120 (PID $pid)"
    jobs -l
    info "In your own interactive shell use:  sleep 300 &  ->  jobs  ->  fg %1  ->  Ctrl+Z  ->  bg %1"
}

zombie_check() {
    header "Zombie Process Check"
    local z; z=$(ps -eo stat,pid,ppid,comm | awk '$1 ~ /^Z/')
    [[ -z $z ]] && ok "No zombie processes found" || { warn "Zombies found:"; echo "$z"; }
}

resource_alert() {            # resource_alert [cpu-load-limit] [mem-limit-%]
    local load_limit="${1:-2}" mem_limit="${2:-85}" load mem
    load=$(cut -d' ' -f1 /proc/loadavg)
    mem=$(free | awk '/^Mem:/ {printf "%.0f", $3*100/$2}')
    awk -v l="$load" -v m="$load_limit" 'BEGIN{exit !(l>m)}' \
        && warn "1-min load average $load exceeds $load_limit" || ok "Load average OK ($load)"
    [[ $mem -ge $mem_limit ]] && warn "Memory usage ${mem}% exceeds ${mem_limit}%" || ok "Memory usage OK (${mem}%)"
}
