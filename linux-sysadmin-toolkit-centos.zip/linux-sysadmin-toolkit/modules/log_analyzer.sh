#!/usr/bin/env bash
# modules/log_analyzer.sh - Experiment 4: filters, regular expressions, pipelines
# Works on the SSH authentication log: /var/log/secure on CentOS/RHEL (override with LOG_FILE)

default_log() {
    if   [[ -n ${LOG_FILE:-} ]];     then echo "$LOG_FILE"
    elif [[ -r /var/log/secure ]];   then echo /var/log/secure
    elif [[ -r /var/log/auth.log ]]; then echo /var/log/auth.log
    else echo ""; fi
}

check_log() {
    LOG="$(default_log)"
    if [[ -z $LOG || ! -r $LOG ]]; then
        err "No readable log found. Run as root or set LOG_FILE=sample/secure_sample.log"
        return 1
    fi
}

failed_summary() {
    check_log || return
    header "SSH Log Summary  ($LOG)"
    local failed accepted invalid
    failed=$(grep -c "Failed password" "$LOG")
    accepted=$(grep -c "Accepted password" "$LOG")
    invalid=$(grep -c "Invalid user" "$LOG")
    printf "  %-28s %s\n" "Failed password attempts:" "$failed"
    printf "  %-28s %s\n" "Successful logins:"        "$accepted"
    printf "  %-28s %s\n" "Invalid-user probes:"      "$invalid"
}

top_attackers() {             # IP addresses with most failed logins
    check_log || return
    header "Top 5 Source IPs of Failed Logins"
    printf "  %-8s %s\n" COUNT IP
    grep -E "Failed password" "$LOG" \
      | sed -E 's/.* from ([0-9]{1,3}(\.[0-9]{1,3}){3}) .*/\1/' \
      | sort | uniq -c | sort -rn | head -5 \
      | awk '{printf "  %-8s %s\n", $1, $2}'
}

top_targets() {               # usernames most often tried
    check_log || return
    header "Top 5 Usernames Targeted"
    printf "  %-8s %s\n" COUNT USER
    grep -E "Failed password" "$LOG" \
      | sed -E 's/.*Failed password for (invalid user )?([^ ]+) from.*/\2/' \
      | sort | uniq -c | sort -rn | head -5 \
      | awk '{printf "  %-8s %s\n", $1, $2}'
}

hourly_pattern() {            # attacks per hour (cut extracts the HH field)
    check_log || return
    header "Failed Logins per Hour of Day"
    grep -F "Failed password" "$LOG" | cut -c8-9 | sort | uniq -c \
      | awk '{printf "  %s:00  %-4s ", $2, $1; for(i=0;i<$1/4;i++) printf "#"; print ""}'
}

search_log() {                # case-insensitive keyword / regex search
    check_log || return
    read -rp "Keyword or regex (e.g. 'root|admin'): " pat
    [[ -z $pat ]] && return
    local n; n=$(grep -ciE -- "$pat" "$LOG")
    info "$n matching lines. Showing first 10:"
    grep -inE -- "$pat" "$LOG" | head -10
}

anonymise_log() {             # sed replaces the last IP octet before sharing a log
    check_log || return
    local out="${1:-/tmp/log_anonymised.txt}"
    sed -E 's/([0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3})\.[0-9]{1,3}/\1.xxx/g' "$LOG" > "$out"
    ok "Anonymised copy written to $out"; head -3 "$out"
}

log_report() {                # full text report (also used by cron)
    failed_summary; top_attackers; top_targets; hourly_pattern
}
