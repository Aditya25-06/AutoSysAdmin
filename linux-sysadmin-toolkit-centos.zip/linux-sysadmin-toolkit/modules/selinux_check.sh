#!/usr/bin/env bash
# modules/selinux_check.sh - Experiment 5: SELinux modes, contexts and denials

selinux_mode() {
    command -v getenforce &>/dev/null || { echo "not installed"; return; }
    getenforce
}

selinux_status() {
    header "SELinux Status"
    need_cmd getenforce || return
    local mode; mode=$(getenforce)
    case $mode in
        Enforcing)  ok   "Mode: Enforcing  - policy is being enforced (recommended)";;
        Permissive) warn "Mode: Permissive - violations are logged but NOT blocked";;
        Disabled)   err  "Mode: Disabled   - SELinux is off";;
    esac
    command -v sestatus &>/dev/null && sestatus | head -8
    echo; echo "Persistent setting in /etc/selinux/config:"
    grep -E '^SELINUX=' /etc/selinux/config 2>/dev/null || echo "  (file not found)"
}

selinux_set_mode() {          # temporary change only (lost on reboot)
    require_root || return
    need_cmd setenforce || return
    echo "1) Enforcing   2) Permissive"
    read -rp "Choose: " c
    case $c in
        1) setenforce 1 && ok "Switched to Enforcing (until reboot)";;
        2) setenforce 0 && warn "Switched to Permissive (until reboot)";;
        *) err "Invalid choice";;
    esac
    info "To make it permanent edit SELINUX= in /etc/selinux/config"
}

selinux_file_context() {      # explain user:role:type:level of a file
    need_cmd ls || return
    read -rp "File or directory path: " f
    [[ -e $f ]] || { err "Not found"; return; }
    local ctx; ctx=$(ls -Zd "$f" | awk '{print $1}')
    echo "Context : $ctx"
    IFS=: read -r u r t l <<< "$ctx"
    printf "  %-8s %s\n  %-8s %s\n  %-8s %s\n  %-8s %s\n" \
        "User:" "$u (SELinux identity)" \
        "Role:" "$r (what roles the user may assume)" \
        "Type:" "$t (the label policy rules actually check)" \
        "Level:" "$l (MLS/MCS sensitivity)"
}

selinux_restore() {
    require_root || return
    need_cmd restorecon || return
    read -rp "Path to relabel to default context: " p
    [[ -e $p ]] && restorecon -Rv "$p" || err "Path not found"
}

selinux_denials() {
    header "Recent SELinux (AVC) Denials"
    if command -v ausearch &>/dev/null && [[ $EUID -eq 0 ]]; then
        ausearch -m avc -ts recent 2>/dev/null | tail -20 || true
    elif [[ -r /var/log/audit/audit.log ]]; then
        grep -F "avc:  denied" /var/log/audit/audit.log | tail -10
    else
        info "No audit log readable (run as root on CentOS to see denials)."
    fi
}
