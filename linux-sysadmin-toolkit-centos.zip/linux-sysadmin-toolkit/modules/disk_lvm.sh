#!/usr/bin/env bash
# modules/disk_lvm.sh - Experiments 1 & 2: disks, partitions, LVM, swap

disk_overview() {
    header "Disk Overview"
    echo "${BOLD}Block devices:${RESET}";           lsblk -o NAME,SIZE,TYPE,FSTYPE,MOUNTPOINT
    echo; echo "${BOLD}Filesystem usage:${RESET}";  df -hT -x tmpfs -x devtmpfs
    echo; echo "${BOLD}Memory and swap:${RESET}";   free -h
    swapon --show 2>/dev/null || true
}

disk_usage_alert() {          # disk_usage_alert [threshold-percent]
    local limit="${1:-80}" out
    out=$(df -hP -x tmpfs -x devtmpfs | awk -v lim="$limit" 'NR>1 {
            gsub("%","",$5);
            if ($5+0 >= lim) printf "  %s is %s%% full (mounted on %s)\n", $1, $5, $6 }')
    if [[ -n $out ]]; then warn "Filesystems above ${limit}% usage:"; echo "$out"
    else ok "All filesystems are below ${limit}% usage."; fi
}

lvm_status() {
    header "LVM Status"
    need_cmd pvs || return
    echo "${BOLD}Physical Volumes:${RESET}"; pvs
    echo; echo "${BOLD}Volume Groups:${RESET}";   vgs
    echo; echo "${BOLD}Logical Volumes:${RESET}"; lvs
}

partition_helper() {          # fdisk (interactive) followed by mkfs + mount
    require_root || return
    lsblk -d -o NAME,SIZE,TYPE | grep disk
    read -rp "Disk to partition (e.g. /dev/sdb): " disk
    [[ -b $disk ]] || { err "$disk is not a block device"; return; }
    warn "fdisk will open now. Use n (new), t (type), p (print), w (write)."
    fdisk "$disk"
    partprobe "$disk" 2>/dev/null
    read -rp "New partition to format (e.g. /dev/sdb1, blank to skip): " part
    [[ -z $part ]] && return
    [[ -b $part ]] || { err "$part not found"; return; }
    read -rp "Filesystem [xfs/ext4] (default xfs): " fs; fs="${fs:-xfs}"
    confirm "Format $part as $fs? ALL DATA ON IT WILL BE LOST" || return
    mkfs."$fs" "$part" || { err "mkfs failed"; return; }
    read -rp "Mount point (e.g. /data): " mp
    mkdir -p "$mp" && mount "$part" "$mp" && ok "$part mounted on $mp"
}

lvm_create_wizard() {
    require_root || return
    need_cmd pvcreate || return
    lsblk -d -o NAME,SIZE,TYPE | grep disk
    read -rp "Spare disk or partition for LVM (e.g. /dev/sdc): " dev
    [[ -b $dev ]] || { err "$dev is not a block device"; return; }
    read -rp "Volume group name: " vg;   valid_name "$vg" || { err "bad name"; return; }
    read -rp "Logical volume name: " lv; valid_name "$lv" || { err "bad name"; return; }
    read -rp "LV size (e.g. 500M or 2G): " size
    read -rp "Mount point (e.g. /data): " mp
    confirm "Create PV/VG/LV on $dev? ALL DATA ON IT WILL BE LOST" || return

    pvcreate "$dev" || return
    if vgs "$vg" &>/dev/null; then vgextend "$vg" "$dev"; else vgcreate "$vg" "$dev"; fi || return
    lvcreate -L "$size" -n "$lv" "$vg" || return
    mkfs.xfs "/dev/$vg/$lv" || return
    mkdir -p "$mp" && mount "/dev/$vg/$lv" "$mp" || return
    cp /etc/fstab "/etc/fstab.bak.$(date +%s)"
    echo "/dev/$vg/$lv  $mp  xfs  defaults  0 0" >> /etc/fstab
    ok "LVM volume /dev/$vg/$lv ready and mounted on $mp (fstab updated)"
}

lvm_extend() {
    require_root || return
    need_cmd lvextend || return
    lvs
    read -rp "Volume group: " vg
    read -rp "Logical volume: " lv
    read -rp "Grow by (e.g. +500M): " size
    lvextend -r -L "$size" "/dev/$vg/$lv" && ok "Extended and resized the filesystem of /dev/$vg/$lv"
}

swap_create() {
    require_root || return
    read -rp "Swap file path [/swapfile]: " sf; sf="${sf:-/swapfile}"
    read -rp "Size in MB [512]: " mb;          mb="${mb:-512}"
    [[ $mb =~ ^[0-9]+$ ]] || { err "Size must be a number"; return; }
    [[ -e $sf ]] && { err "$sf already exists"; return; }
    info "Creating ${mb}MB swap file..."
    dd if=/dev/zero of="$sf" bs=1M count="$mb" status=none || return
    chmod 600 "$sf"; mkswap "$sf" && swapon "$sf" || return
    echo "$sf none swap defaults 0 0" >> /etc/fstab
    ok "Swap file $sf active"; swapon --show
}
