#!/usr/bin/env bash
# modules/user_mgmt.sh - Experiment 3: users, groups, permissions and ACLs

user_add() {
    require_root || return
    read -rp "Username: " u
    valid_name "$u" || { err "Invalid username"; return; }
    id "$u" &>/dev/null && { err "User $u already exists"; return; }
    read -rp "Home directory [/home/$u]: " h; h="${h:-/home/$u}"
    read -rp "Login shell [/bin/bash]: " s;   s="${s:-/bin/bash}"
    [[ -x $s ]] || { err "Shell $s not found"; return; }
    read -rp "Account expiry YYYY-MM-DD (blank = never): " e
    local args=(-m -d "$h" -s "$s")
    if [[ -n $e ]]; then
        date -d "$e" +%F &>/dev/null || { err "Invalid date"; return; }
        args+=(-e "$e")
    fi
    useradd "${args[@]}" "$u" && ok "User $u created" && passwd "$u"
}

user_delete() {
    require_root || return
    read -rp "Username to delete: " u
    id "$u" &>/dev/null || { err "No such user"; return; }
    [[ $(id -u "$u") -lt 1000 ]] && { err "Refusing to delete a system account"; return; }
    confirm "Delete $u and their home directory?" && userdel -r "$u" && ok "User $u removed"
}

group_create() {
    require_root || return
    read -rp "New group name: " g
    valid_name "$g" || { err "Invalid group name"; return; }
    groupadd "$g" && ok "Group $g created"
}

group_add_member() {
    require_root || return
    read -rp "Username: " u; read -rp "Group: " g
    if ! id "$u" &>/dev/null || ! getent group "$g" &>/dev/null; then
        err "User or group does not exist"; return
    fi
    usermod -aG "$g" "$u" && ok "$u added to $g"
}

user_report() {
    header "Regular User Accounts (UID >= 1000)"
    printf "%-14s %-6s %-20s %-18s\n" USER UID SHELL "ACCOUNT EXPIRES"
    awk -F: '$3>=1000 && $3<60000 {print $1":"$3":"$7}' /etc/passwd |
    while IFS=: read -r name uid sh; do
        exp=$(chage -l "$name" 2>/dev/null | awk -F': ' '/Account expires/{print $2}')
        printf "%-14s %-6s %-20s %-18s\n" "$name" "$uid" "$sh" "${exp:-n/a}"
    done
    echo; echo "${BOLD}Groups with members:${RESET}"
    awk -F: '$4!="" && $3>=1000 {print "  "$1" -> "$4}' /etc/group
}

shared_dir_setup() {          # group-shared directory using chown/chgrp + chmod + ACL
    require_root || return
    read -rp "Directory path (e.g. /srv/project): " d
    read -rp "Owning group: " g
    getent group "$g" &>/dev/null || { err "Group $g does not exist"; return; }
    mkdir -p "$d"
    chown root:"$g" "$d"
    chmod 2770 "$d"                    # setgid bit keeps new files in the group
    ok "Created $d  (owner root, group $g, mode 2770)"
    read -rp "Give one extra user read-only ACL access? (username or blank): " u
    if [[ -n $u ]] && id "$u" &>/dev/null; then
        need_cmd setfacl && setfacl -m u:"$u":rx "$d" && setfacl -d -m u:"$u":rx "$d"
    fi
    ls -ld "$d"
    command -v getfacl &>/dev/null && getfacl -p "$d"
}

perm_fix() {                  # chown / chgrp / chmod wizard
    require_root || return
    read -rp "File or directory: " f; [[ -e $f ]] || { err "Not found"; return; }
    read -rp "New owner (blank = keep): " o
    read -rp "New group (blank = keep): " g
    read -rp "New mode e.g. 640 (blank = keep): " m
    [[ -n $o ]] && chown "$o" "$f"
    [[ -n $g ]] && chgrp "$g" "$f"
    [[ -n $m ]] && chmod "$m" "$f"
    ls -l "$f"; ok "Permissions updated"
}
