#!/usr/bin/env bash
# modules/scheduler.sh - Experiment 6: cron job scheduling and automated backup

CRON_TAG="# sysadmin-toolkit"

_cron_add() {                 # _cron_add "<schedule>" "<command>"
    local sched="$1" cmd="$2"
    ( crontab -l 2>/dev/null | grep -vF "$cmd"; echo "$sched $cmd $CRON_TAG" ) | crontab -
}

schedule_health_report() {
    local base; base="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
    echo "1) Every day at 06:00    2) Every hour    3) Custom cron expression"
    read -rp "Choose: " c
    local s
    case $c in
        1) s="0 6 * * *";;
        2) s="0 * * * *";;
        3) read -rp "Cron expression (min hour dom mon dow): " s;;
        *) err "Invalid choice"; return;;
    esac
    [[ $(wc -w <<< "$s") -eq 5 ]] || { err "A cron expression needs exactly 5 fields"; return; }
    _cron_add "$s" "$base/toolkit.sh --report"
    ok "Health report scheduled: $s"
}

schedule_backup() {
    local base; base="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
    _cron_add "30 2 * * 0" "$base/toolkit.sh --backup"
    ok "Weekly backup of /etc scheduled for Sunday 02:30"
}

run_backup() {                # compressed, date-stamped archive with retention
    local dest="${BACKUP_DIR:-/var/backups/toolkit}"
    mkdir -p "$dest" 2>/dev/null || dest="$HOME/toolkit-backups" && mkdir -p "$dest"
    local file="$dest/etc_backup_$(date +%F_%H%M).tar.gz"
    if tar -czf "$file" /etc 2>/dev/null; then
        ok "Backup created: $file ($(du -h "$file" | cut -f1))"
    else
        err "Backup failed"; return 1
    fi
    find "$dest" -name 'etc_backup_*.tar.gz' -mtime +14 -delete   # keep 14 days
}

list_cron_jobs() {
    header "Scheduled Toolkit Jobs"
    crontab -l 2>/dev/null | grep -F "$CRON_TAG" || info "No toolkit jobs scheduled."
    echo; echo "${BOLD}Cron service:${RESET}"
    systemctl is-active crond 2>/dev/null || systemctl is-active cron 2>/dev/null || true
}

remove_cron_jobs() {
    confirm "Remove all toolkit cron jobs?" || return
    crontab -l 2>/dev/null | grep -vF "$CRON_TAG" | crontab -
    ok "Toolkit cron jobs removed"
}
